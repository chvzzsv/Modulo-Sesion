<?php
class ConexionPDO{
    private $host;
    private $dbname;
    private $usuario;
    private $contrasena;
    private $conexion;

    public function __construct($host, $dbname, $usuario, $contrasena)
    {
        $this->host = $host;
        $this->dbname = $dbname;
        $this->usuario = $usuario;
        $this->contrasena = $contrasena;
    }

    public function conectar(){
        try {
            $opciones = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            );
            $this->conexion = new PDO('mysql:host='.$this->host.';dbname='.$this->dbname, $this->usuario, $this->contrasena, $opciones);

          
            $this->conexion->exec("USE " . $this->dbname);

            if($this->conexion != null){
                // echo "Conexión exitosa";
            } else {
                // echo "Conexión fallida";
            }
        } catch (PDOException $e){
            echo "Error de conexión" .$e->getMessage();
            die();
        }
    }

    public function getConnection(){
        return $this->conexion;
    }

    public function desconectar(){
        return $this->conexion = null;
    }
}

?>